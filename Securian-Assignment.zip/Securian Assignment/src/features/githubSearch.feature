Feature: Github test
    As a Developer in Test
    I want to search for webdriverio repository
    So that I can use it in my future tests

Scenario: open URL
    Given I open the url "https://github.com/"
    Then  I expect the url to contain "github.com"
    And   I expect that the title is "GitHub: Let’s build from here · GitHub"

Scenario: search for webdriverio repository
    Given I open the url "https://github.com/search"
    And   the element "[placeholder='Search GitHub']" not contains any text
    And   I clear the inputfield "[placeholder='Search GitHub']"
    And   I add "webdriverio" to the inputfield "[placeholder='Search GitHub']"
    When  I press "Enter"
    # Then  I expect that element "span[data-target='qbsearch-input.inputButtonText']" contains the text "webdriverio"
    # And   I expect that container "div[data-testid='results-list']:first-child" contains the text "Next-gen browser and mobile automation test framework for Node.js"
